package com.fa.bean;

import com.fa.util.ExcelField;

import java.math.BigDecimal;

public class StudentBaseInfo {
    private Integer id;
    @ExcelField(title = "编号", align = 2, sort = 1)
    private String no;
    @ExcelField(title = "姓名", align = 2, sort = 2)
    private String name;
    @ExcelField(title = "个数", align = 2, sort = 3)
    private String idnum;
    @ExcelField(title = "性别", align = 2, sort = 4)
    private String sex;
    @ExcelField(title = "班级", align = 2, sort = 5)
    private BigDecimal grade;


    @Override
    public String toString() {
        return "StudentBaseInfo [id=" + id + ", no=" + no + ", name=" + name + ", idnum=" + idnum + ", sex=" + sex
                + ", grade=" + grade + "]";
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getNo() {
        return no;
    }

    public void setNo(String no) {
        this.no = no;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public String getIdnum() {
        return idnum;
    }

    public void setIdnum(String idnum) {
        this.idnum = idnum;
    }

    public BigDecimal getGrade() {
        return grade;
    }

    public void setGrade(BigDecimal grade) {
        this.grade = grade;
    }

}