package com.fa.bean;

import com.fa.util.ExcelField;

import java.math.BigDecimal;

public class StudentStatistics {
    @ExcelField(title = "编号", align = 2, sort = 1)
    private Integer id;
    @ExcelField(title = "总分", align = 2, sort = 2)
    private BigDecimal totalGrade;
    @ExcelField(title = "平均分", align = 2, sort = 3)
    private BigDecimal avgGrade;

    public Integer getId() {
        return id;
    }
    public void setId(Integer id) {
        this.id = id;
    }

    public BigDecimal getTotalGrade() {
        return totalGrade;
    }

    public void setTotalGrade(BigDecimal totalGrade) {
        this.totalGrade = totalGrade;
    }

    public BigDecimal getAvgGrade() {
        return avgGrade;
    }

    public void setAvgGrade(BigDecimal avgGrade) {
        this.avgGrade = avgGrade;
    }

    @Override
    public String toString() {
        return "StudentStatistics [id=" + id + ", totalGrade=" + totalGrade + ", avgGrade=" + avgGrade + "]";
    }

}