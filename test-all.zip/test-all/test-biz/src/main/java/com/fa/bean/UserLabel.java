package com.fa.bean;

public class UserLabel {

}
