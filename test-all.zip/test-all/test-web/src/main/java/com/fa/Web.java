package com.fa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Web {
    public static void main(String[] args) {
        SpringApplication.run(Web.class, args);
    }
}
