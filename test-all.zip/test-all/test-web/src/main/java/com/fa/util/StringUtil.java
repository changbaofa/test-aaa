package com.fa.util;

import java.text.DecimalFormat;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;

/**
 * 字符串处理工具类
 */
@SuppressWarnings({ "unused", "Duplicates" })
public final class StringUtil extends StringUtils {

	/**
	 * 对象为NULL时，转换为空
	 */
	public static String convertNull2Empty(String obj) {
		return null == obj ? "" : obj;
	}

	/**
	 * 验收数字是否为正数
	 */
	public static boolean isPositiveNum(String str) {
		return str != null && Pattern.compile("^\\d+$").matcher(str).matches();
	}

	/**
	 * 验证两个对象是否相等
	 */
	public static boolean isEqual(Object obj1, Object obj2) {
		return obj1 == null && obj2 == null || obj1 != null && obj2 != null && obj1.equals(obj2);
	}

	/**
	 * 验证对象是否为空或NULl
	 */
	public static boolean isEmptyOrNull(Object str) {
		return null == str || "".equals(str);
	}

	/**
	 * 验证字符串是否为空字符串或NULl
	 */
	public static boolean isSpaceOrNull(String str) {
		return null == str || "".equals(str.trim());
	}

	/**
	 * 验证对象不为空也不为NULL
	 */
	public static boolean isNotEmptyOrNull(Object str) {
		return null != str && !"".equals(str);
	}

	/**
	 * 验证对象是否为null
	 */
	public static boolean isNull(Object str) {
		return null == str || "".equals(str);
	}

	/**
	 * 验证字符串为数据
	 */
	public static boolean isNumeric(String str) {
		return !isSpaceOrNull(str) && Pattern.compile("^-?\\d+$").matcher(str).matches();
	}

	/**
	 * 自定义正则表达式进行各类验证
	 */
	public static boolean regularValid(String str, String regex) {
		return Pattern.compile(regex).matcher(str).matches();
	}

	/**
	 * 字符替换
	 */
	public static String replace(String inStr, String searchString, String replacement) {
		return StringUtils.replace(inStr, searchString, replacement);
	}

	/**
	 * 字符串前自动补充所需字符
	 */
	public static String flushLeft(char c, long length, String content) {
		if (content.length() > length) {
			return content;
		} else {
			StringBuilder cs = new StringBuilder("");
			for (int i = 0; i < length - content.length(); i++) {
				cs.append(c);
			}
			return cs.append(content).toString();
		}
	}

	/**
	 * 汉字转拼音缩写
	 */
	public static String getPYString(String str) {
		String tempStr = "";
		for (int i = 0; i < str.length(); i++) {
			char c = str.charAt(i);
			// 字母和符号原样保留
			if ((int) c >= 33 && (int) c <= 126) {
				tempStr += String.valueOf(c);
			} else {
				// 累加拼音声母
				tempStr += getPYChar(String.valueOf(c));
			}
		}
		return tempStr;
	}

	/**
	 * 获取小数点后两个小数点的字符串
	 */
	public static String getMoneyStr(double value) {
		DecimalFormat df = new DecimalFormat("##.##");
		Double fmtValue = Double.parseDouble(df.format(value)) + 0.001;
		df = new DecimalFormat("##.###");
		String tempStr = df.format(fmtValue);
		return tempStr.substring(0, tempStr.length() - 1);
	}

	/**
	 * 取单个字符的拼音声母
	 */
	public static String getPYChar(String c) {
		/** 对出错的空格进行过滤字符进行过滤 **/
		if (c.trim().length() == 0) {
			return c;
		}
		byte[] array = String.valueOf(c).getBytes();
		int i = (short) (array[0] + 256) * 256 + ((short) (array[1] + 256));

		if (i < 0xB0A1) {
			return "*";
		} else if (i < 0xB0C5) {
			return "A";
		} else if (i < 0xB2C1) {
			return "B";
		} else if (i < 0xB4EE) {
			return "C";
		} else if (i < 0xB6EA) {
			return "D";
		} else if (i < 0xB7A2) {
			return "E";
		} else if (i < 0xB8C1) {
			return "F";
		} else if (i < 0xB9FE) {
			return "G";
		} else if (i < 0xBBF7) {
			return "H";
		} else if (i < 0xBFA6) {
			return "J";
		} else if (i < 0xC0AC) {
			return "K";
		} else if (i < 0xC2E8) {
			return "L";
		} else if (i < 0xC4C3) {
			return "M";
		} else if (i < 0xC5B6) {
			return "N";
		} else if (i < 0xC5BE) {
			return "O";
		} else if (i < 0xC6DA) {
			return "P";
		} else if (i < 0xC8BB) {
			return "Q";
		} else if (i < 0xC8F6) {
			return "R";
		} else if (i < 0xCBFA) {
			return "S";
		} else if (i < 0xCDDA) {
			return "T";
		} else if (i < 0xCEF4) {
			return "W";
		} else if (i < 0xD1B9) {
			return "X";
		} else if (i < 0xD4D1) {
			return "Y";
		} else if (i < 0xD7FA) {
			return "Z";
		} else {
			return "*";
		}
	}

	/**
	 * 目标转化为字符串，null转化为默认值
	 */
	public static String obj2Str(Object target, String defaultValue) {
		String value = defaultValue;
		if (target != null) {
			value = String.valueOf(target);
		}
		return value;
	}

	/**
	 * 目标转化为字符串，null转化为""
	 */
	public static String obj2Str(Object target) {
		return obj2Str(target, "");
	}

	/**
	 * 验证是否包含字符串
	 */
	public static boolean contains(String str, String search) {
		return !(str == null || search == null) && str.contains(search);
	}

	/**
	 * 剔除特殊字符
	 */
	public static String trimSymbol(String inStr) {
		if (inStr == null || "".equals(inStr.trim())) {
			return "";
		}
		return inStr.replaceAll("\\D", "");
	}

	/**
	 * 去掉字符串最后一位
	 */
	public static String deleteLast(String str) {
		if (!"".equals(str)) {
			str = str.substring(0, str.length() - 1);
		}
		return str;
	}

}
