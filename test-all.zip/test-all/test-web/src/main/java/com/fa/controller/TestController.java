package com.fa.controller;

import com.fa.bean.StudentBaseInfo;
import com.fa.service.TestService;
import com.fa.util.HttpClientUtilNew;
import com.fa.util.ImportExcelUtil;
import org.apache.poi.ss.usermodel.Workbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

@Controller

public class TestController {
    @Autowired
    private TestService testService;

    @Autowired
    private HttpClientUtilNew httpClientUtilNew;

    @ResponseBody
    @GetMapping("/aaa")
    public String aaa() {
        return testService.getDate();
    }

    @RequestMapping("/bbb")
    public String index(HttpServletRequest request) {
        request.setAttribute("key", "hello world");
        return "user/hello";
    }

    @GetMapping("/ccc")
    public String ccc() {
        return "index.html";
    }

    @RequestMapping(value = "/uploadFile", method = RequestMethod.POST, produces = "application/json;charset=utf-8")
    @ResponseBody
    public String importComment(@RequestParam MultipartFile file, String name) {
        String fileName = file.getName();
        try {
            InputStream in = file.getInputStream();
            Workbook wb = ImportExcelUtil.chooseWorkbook(fileName, in);
            StudentBaseInfo studentBaseInfo = new StudentBaseInfo();
            List<StudentBaseInfo> readDateListT = ImportExcelUtil.readDateListT(wb, studentBaseInfo, 2, 0);
            System.out.println(readDateListT);
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "aaa";
    }

    @RequestMapping(value = "/getList", method = RequestMethod.GET, produces = "application/json;charset=utf-8")
    public String getList() {
        String s = "";
        for (int i = 0; i < 100; i++) {
            s = httpClientUtilNew.GET("https://club.autohome.com.cn/bbs/thread/1f6fb74914701f24/75229351-1.html");
        }
        return s;
    }

}
