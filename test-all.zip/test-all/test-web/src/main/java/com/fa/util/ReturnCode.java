package com.fa.util;

/**
 * @author Yang
 * @date 2018/1/22 17:18
 * @describe
 */
public interface ReturnCode {

    public int getCode();

    public String getMessage();
}
