package com.fa.util;

import java.beans.IntrospectionException;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.net.URLEncoder;
import java.util.*;

import org.apache.http.Consts;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.StatusLine;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.DefaultConnectionReuseStrategy;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultConnectionKeepAliveStrategy;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;


/**
 * 通用接口调用工具
 */
@Component
public class HttpClientUtilNew {

	private Logger logger = LoggerFactory.getLogger(HttpClientUtil.class);

	private static final String CHARSET_UTF8 = "UTF-8";
	private static final String GENERAL_CONTENT_TYPE = "application/x-www-form-urlencoded;charset=UTF-8";
	private static final String JSON_CONTENT_TYPE = "application/json;charset=UTF-8";

	private static final int maxConnectionsPerHost = 100;
	private static final int maxTotalConnections = 100;
	private static final int socketTimeout = 20000;
	private static final int connectionTimeout = 30000;
	private static final String userAgentString = "Chrome/21.0.1180.89";
	private static Collection<BasicHeader> defaultHeaders = new HashSet<>();

	private static CloseableHttpClient httpClient;

	static {
		defaultHeaders.add(new BasicHeader("HBC-ROUTE-GROUP", "wangxiaofeng"));
		RequestConfig requestConfig = RequestConfig.custom()
				.setConnectionRequestTimeout(connectionTimeout).setConnectTimeout(connectionTimeout)
				.setSocketTimeout(socketTimeout).build();

		PoolingHttpClientConnectionManager connectionManager = new PoolingHttpClientConnectionManager();
		connectionManager.setMaxTotal(maxTotalConnections);
		connectionManager.setDefaultMaxPerRoute(maxConnectionsPerHost);

		HttpClientBuilder clientBuilder = HttpClientBuilder.create();
		clientBuilder.setDefaultRequestConfig(requestConfig);

		clientBuilder.setConnectionManager(connectionManager);
		clientBuilder.setKeepAliveStrategy(new DefaultConnectionKeepAliveStrategy());
		clientBuilder.setConnectionReuseStrategy(new DefaultConnectionReuseStrategy());
		clientBuilder.setUserAgent(userAgentString);
		clientBuilder.setDefaultHeaders(defaultHeaders);
		httpClient = clientBuilder.build();
	}

	public String GET(String url) {
		return GET(url, null, null, null, true);
	}

	public String GET(String url, Boolean printLog) {
		return GET(url, null, null, null, printLog);
	}

	public String GET(String url, Map<String, Object> params) {
		return GET(url, null, params, null, true);
	}

	public String GET(String url, Map<String, Object> params, Boolean printLog) {
		return GET(url, null, params, null, printLog);
	}

	public String GET(String url, Map<String, Object> headers, Map<String, Object> params) {
		return GET(url, headers, params, null, true);
	}

	public String GET(String url, Map<String, Object> headers, Map<String, Object> params, Boolean printLog) {
		return GET(url, headers, params, null, printLog);
	}

	public String GET(String url, Object bean) {
		return GET(url, null, null, bean, true);
	}

	public String GET(String url, Object bean, Boolean printLog) {
		return GET(url, null, null, bean, printLog);
	}

	public String GET(String url, Map<String, Object> headers, Map<String, Object> params, Object bean,
			Boolean printLog) {
		long startTime = System.currentTimeMillis();
		String realUrl = url;
		if (null == params) {
			params = new HashMap<>();
		}
		if (null != bean) {
			try {
				// noinspection unchecked
				params.putAll(BeanUtil.convertBeanToMap(bean));
			} catch (IntrospectionException | IllegalAccessException | InvocationTargetException e) {
				logger.error("", e);
			}
		}
		if (0 < params.size()) {
			StringBuilder paramStr = new StringBuilder();
			for (Map.Entry<String, Object> entry : params.entrySet()) {
				if (!StringUtil.isEmptyOrNull(entry.getValue())) {
					if (entry.getValue() instanceof Date) {
						try {
							paramStr.append(entry.getKey()).append("=").append(URLEncoder.encode(
									DateUtil.dateToString((Date) entry.getValue(), DateUtil.COMMON_TIME_FORMAT),
									CHARSET_UTF8)).append("&");
						} catch (UnsupportedEncodingException e) {
							logger.error("", e);
						}
					} else {
						try {
							paramStr.append(entry.getKey()).append("=")
									.append(URLEncoder.encode(entry.getValue().toString(), CHARSET_UTF8)).append("&");
						} catch (UnsupportedEncodingException e) {
							logger.error("", e);
						}
					}
				}
			}
			realUrl = url.indexOf('?', 1) > -1 ? url + paramStr : url + "?" + paramStr;
		}

		HttpGet httpGet = new HttpGet(realUrl);
		if (null != headers && 0 < headers.size()) {
			httpGet = convertHeaders(httpGet, headers);
		}

		CloseableHttpResponse response = null;
		try {
			response = httpClient.execute(httpGet);
		} catch (IOException e) {
			logger.error("", e);
		}

		if (null != response) {
			try {
				StatusLine statusLine = response.getStatusLine();
				String ret = EntityUtils.toString(response.getEntity(), "UTF-8");
				long endTime = System.currentTimeMillis();
				if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
					if (printLog) {
						logger.info("【接口】 - {}", realUrl);
						// logger.info("【返回】 - {}", ret);
						// logger.info("【耗时】 - {} ms", endTime - startTime);
					}
					return ret;
				} else {
					logger.error("==================== api exception print ====================");
					logger.error("【接口exception】 - {}", realUrl);
					logger.error("【状态exception】 - {}", statusLine.getStatusCode());
					logger.error("【返回exception】 - {}", ret);
					logger.error("【耗时exception】 - {} ms", endTime - startTime);
					throw new BaseException(40010001, "接口返回状态异常");
				}
			} catch (IOException e) {
				logger.error("", e);
			} finally {
				try {
					response.close();
				} catch (IOException e) {
					logger.error("", e);
				}
			}
		}
		throw new BaseException(40010002, "接口调用失败");
	}

	public String POST(String url, Map<String, Object> headers, Map<String, Object> params) {
		return POST(url, headers, params, null, null, true);
	}

	public String POST(String url, Map<String, Object> headers, Map<String, Object> params, Boolean printLog) {
		return POST(url, headers, params, null, null, printLog);
	}

	public String POST(String url, Map<String, Object> headers, String json) {
		return POST(url, headers, null, json, null, true);
	}

	public String POST(String url, Map<String, Object> headers, String json, Boolean printLog) {
		return POST(url, headers, null, json, null, printLog);
	}

	public String POST(String url, Map<String, Object> headers, Object bean) {
		return POST(url, headers, null, null, bean, true);
	}

	public String POST(String url, Map<String, Object> headers, Object bean, Boolean printLog) {
		return POST(url, headers, null, null, bean, printLog);
	}

	public String POST(String url, Map<String, Object> params) {
		return POST(url, null, params, null, null, true);
	}

	public String POST(String url, Map<String, Object> params, Boolean printLog) {
		return POST(url, null, params, null, null, printLog);
	}

	public String POST(String url, String json) {
		return POST(url, null, null, json, null, true);
	}

	public String POST(String url, String json, Boolean printLog) {
		return POST(url, null, null, json, null, printLog);
	}

	public String POST(String url, Object bean) {
		return POST(url, null, null, null, bean, true);
	}

	public String POST(String url, Object bean, Boolean printLog) {
		return POST(url, null, null, null, bean, printLog);
	}

	public String POST(String url, Map<String, Object> headers, Map<String, Object> params, String json, Object bean,
			Boolean printLog) {
		long startTime = System.currentTimeMillis();
		if (printLog) {
			logger.info("! -> url : {}", url);
			if (null != headers) {
				logger.info("! -> headers : {}", JSONObject.toJSONString(headers));
			}
			if (null != params) {
				logger.info("! -> params : {}", JSONObject.toJSONString(params));
			}
			if (null != json) {
				logger.info("! -> json : {}", json);
			}
			if (null != bean) {
				logger.info("! -> bean : {}", JSONObject.toJSONString(bean));
			}
		}
		HttpPost httpPost = new HttpPost(url);
		if (null != headers && 0 < headers.size()) {
			httpPost = convertHeaders(httpPost, headers);
		}
		if (!StringUtil.isEmptyOrNull(json)) {
			httpPost = convertJson(httpPost, json);
		} else if (null != params && 0 < params.size()) {
			httpPost = convertParams(httpPost, params);
		} else if (null != bean) {
			try {
				httpPost = convertBean(httpPost, bean);
			} catch (IllegalAccessException | IntrospectionException | InvocationTargetException e) {
				logger.error("", e);
			}
		}

		CloseableHttpResponse response = null;
		try {
			response = httpClient.execute(httpPost);
		} catch (IOException e) {
			logger.error("", e);
		}

		if (null != response) {

			try {
				StatusLine statusLine = response.getStatusLine();
				String ret = EntityUtils.toString(response.getEntity(), "UTF-8");
				long endTime = System.currentTimeMillis();
				if (statusLine.getStatusCode() == HttpStatus.SC_OK) {
					if (printLog) {
						logger.info("【接口】 - {}", url);
						// logger.info("【返回】 - {}", ret);
						// logger.info("【耗时】 - {} ms", endTime - startTime);
					}
					return ret;
				} else {
					logger.error("==================== api exception print ====================");
					logger.error("【接口exception】 - {}", url);
					logger.error("【入参exception】 - {}", null != params ? JSONObject.toJSONString(params) : json);
					logger.error("【状态exception】 - {}", statusLine.getStatusCode());
					logger.error("【返回exception】 - {}", ret);
					logger.error("【耗时exception】 - {} ms", endTime - startTime);
					throw new BaseException(40010001, "接口返回状态异常");
				}
			} catch (IOException e) {
				logger.error("", e);
			} finally {
				try {
					response.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		throw new BaseException(40010002, "接口调用失败");
	}

	private HttpGet convertHeaders(HttpGet httpGet, Map<String, Object> headers) {
		for (Map.Entry<String, Object> entry : headers.entrySet()) {
			if (StringUtil.isEmptyOrNull(httpGet.getFirstHeader(entry.getKey()))) {
				httpGet.addHeader(entry.getKey(), String.valueOf(entry.getValue()));
			} else {
				httpGet.setHeader(entry.getKey(), String.valueOf(entry.getValue()));
			}
		}
		return httpGet;
	}

	private HttpPost convertHeaders(HttpPost httpPost, Map<String, Object> headers) {
		for (Map.Entry<String, Object> entry : headers.entrySet()) {
			if (StringUtil.isEmptyOrNull(httpPost.getFirstHeader(entry.getKey()))) {
				httpPost.addHeader(entry.getKey(), String.valueOf(entry.getValue()));
			} else {
				httpPost.setHeader(entry.getKey(), String.valueOf(entry.getValue()));
			}
		}
		return httpPost;
	}

	private HttpPost convertParams(HttpPost httpPost, Map<String, Object> params) {
		List<NameValuePair> nameValuePairs = new ArrayList<>();
		params.entrySet().stream().filter(entry -> !StringUtil.isEmptyOrNull(entry.getValue())).forEach(entry -> {
			NameValuePair pair = new BasicNameValuePair(entry.getKey(), StringUtil.obj2Str(entry.getValue()));
			nameValuePairs.add(pair);
		});
		UrlEncodedFormEntity entity = new UrlEncodedFormEntity(nameValuePairs, Consts.UTF_8);
		entity.setContentType(GENERAL_CONTENT_TYPE);
		httpPost.setEntity(entity);
		return httpPost;
	}

	private HttpPost convertBean(HttpPost httpPost, Object bean)
			throws IllegalAccessException, IntrospectionException, InvocationTargetException {
		UrlEncodedFormEntity entity = new UrlEncodedFormEntity(BeanUtil.convertBeanToNVP(bean, false), Consts.UTF_8);
		entity.setContentType(GENERAL_CONTENT_TYPE);
		httpPost.setEntity(entity);
		return httpPost;
	}

	private HttpPost convertJson(HttpPost httpPost, String json) {
		StringEntity entity = new StringEntity(json, Consts.UTF_8);
		entity.setContentType(JSON_CONTENT_TYPE);
		httpPost.setEntity(entity);
		return httpPost;
	}

}
