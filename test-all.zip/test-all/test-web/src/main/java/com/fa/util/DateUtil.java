package com.fa.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

@SuppressWarnings({ "WeakerAccess", "unused" })
public class DateUtil {

	/**
	 * 日志记录
	 */
	@SuppressWarnings("unused")
	private static Logger logger = LoggerFactory.getLogger(DateUtil.class);

	public static final String COMPACT_DATE_FORMAT = "yyyyMMdd";
	public static final String COMMON_DATE_FORMAT = "yyyy-MM-dd";
	public static final String COMPACT_TIME_FORMAT = "yyyyMMddHHmmss";
	public static final String COMMON_TIME_FORMAT = "yyyy-MM-dd HH:mm:ss";

	public static int daysBetween(Date early, Date late) {
		Calendar c1 = Calendar.getInstance();
		Calendar c2 = Calendar.getInstance();
		c1.setTime(early);
		c2.setTime(late);
		return daysBetween(c1, c2);
	}

	public static int daysBetween(Calendar early, Calendar late) {
		return (int) (toJulian(late) - toJulian(early));
	}

	public static float toJulian(Calendar c) {
		int Y = c.get(Calendar.YEAR);
		int M = c.get(Calendar.MONTH);
		int D = c.get(Calendar.DATE);
		int A = Y / 100;
		int B = A / 4;
		int C = 2 - A + B;
		float E = (int) (365.25f * (Y + 4716));
		float F = (int) (30.6001f * (M + 1));
		return C + D + E + F - 1524.5f;
	}

	public static String dateIncrease(String isoString, String fmt, int field, int amount) {
		try {
			Calendar cal = GregorianCalendar.getInstance(TimeZone.getTimeZone("GMT"));
			cal.setTime(stringToDate(isoString, fmt));
			cal.add(field, amount);
			return dateToString(cal.getTime(), fmt);
		} catch (Exception ex) {
			return null;
		}
	}

	public static String roll(String isoString, String fmt, int field, boolean up) throws ParseException {
		Calendar cal = GregorianCalendar.getInstance(TimeZone.getTimeZone("GMT"));
		cal.setTime(stringToDate(isoString, fmt));
		cal.roll(field, up);
		return dateToString(cal.getTime(), fmt);
	}

	public static String roll(String isoString, int field, boolean up) throws ParseException {
		return roll(isoString, COMMON_TIME_FORMAT, field, up);
	}

	public static Date stringToDate(String dateString) {
		return stringToDate(dateString, COMMON_DATE_FORMAT);
	}

	public static String dateToString(Date date) {
		return dateToString(date, COMMON_DATE_FORMAT);
	}

	public static Date getCurrentDateTime() {
		return Calendar.getInstance().getTime();
	}

	public static String getCurrentDateString(String pattern) {
		return dateToString(getCurrentDateTime(), pattern);
	}

	public static String getCurrentDateString() {
		return dateToString(getCurrentDateTime(), COMMON_DATE_FORMAT);
	}

	public static String dateToStringWithTime(Date date) {
		return dateToString(date, COMMON_TIME_FORMAT);
	}

	public static Date dateIncreaseByDay(Date date, int days) {
		Calendar cal = GregorianCalendar.getInstance(TimeZone.getTimeZone("GMT"));
		cal.setTime(date);
		cal.add(Calendar.DATE, days);
		return cal.getTime();
	}

	public static Date dateIncreaseByMonth(Date date, int mnt) {
		Calendar cal = GregorianCalendar.getInstance(TimeZone.getTimeZone("GMT"));
		cal.setTime(date);
		cal.add(Calendar.MONTH, mnt);
		return cal.getTime();
	}

	public static Date dateIncreaseByYear(Date date, int mnt) {
		Calendar cal = GregorianCalendar.getInstance(TimeZone.getTimeZone("GMT"));
		cal.setTime(date);
		cal.add(Calendar.YEAR, mnt);
		return cal.getTime();
	}

	public static String dateIncreaseByDay(String date, int days) {
		return dateIncreaseByDay(date, COMPACT_DATE_FORMAT, days);
	}

	public static String dateIncreaseByDay(String date, String fmt, int days) {
		return dateIncrease(date, fmt, Calendar.DATE, days);
	}

	public static Date dateIncreaseBySeconds(Date date, int seconds) {
		Calendar cal = GregorianCalendar.getInstance(TimeZone.getTimeZone("GMT"));
		cal.setTime(date);
		cal.add(Calendar.SECOND, seconds);
		return cal.getTime();
	}

	public static Date dateIncreaseByHour(Date date, int hours) {
		Calendar cal = GregorianCalendar.getInstance(TimeZone.getTimeZone("GMT"));
		cal.setTime(date);
		cal.add(Calendar.HOUR, hours);
		return cal.getTime();
	}

	public static String stringToString(String src, String srcfmt, String desfmt) {
		return dateToString(stringToDate(src, srcfmt), desfmt);
	}

	/*******************************************************************************/

	public static Date stringToDate(String date, String format) {
		if (date == null) {
			return null;
		}
		DateFormat dateFormat;
		try {
			if (format == null) {
				dateFormat = new SimpleDateFormat();
			} else {
				dateFormat = new SimpleDateFormat(format);
			}
			dateFormat.setLenient(false);
			return dateFormat.parse(date);
		} catch (ParseException e) {
			return null;
		}
	}

	public static String dateToString(Date date, String pattern) {
		if (date == null) {
			return null;
		}
		try {
			SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
			simpleDateFormat.setLenient(false);
			return simpleDateFormat.format(date);
		} catch (Exception e) {
			logger.error("", e);
			return null;
		}
	}

	public static Date timeIncreaseByHour(Date time, int hours, String pattern) {
		Calendar calendar = GregorianCalendar.getInstance(TimeZone.getTimeZone("GMT"));
		calendar.setTime(time);
		calendar.add(Calendar.HOUR, hours);
		return calendar.getTime();
	}

	public static String timeIncreaseByHour(String time, int hours, String pattern) {
		return dateToString(timeIncreaseByHour(stringToDate(time, pattern), hours, pattern), pattern);
	}

	public static String timeIncreaseByHour(String time, int hours) {
		return dateToString(timeIncreaseByHour(stringToDate(time, COMMON_TIME_FORMAT), hours, COMMON_TIME_FORMAT), COMMON_TIME_FORMAT);
	}

	public static Date dayStart(Date time, String pattern) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(time);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		return calendar.getTime();
	}

	public static String dayStart(String time, String pattern) {
		return dateToString(dayStart(stringToDate(time, pattern), pattern), pattern);
	}

	public static String dayStart(String time) {
		return dateToString(dayStart(stringToDate(time, COMMON_TIME_FORMAT), COMMON_TIME_FORMAT), COMMON_TIME_FORMAT);
	}

    public static Date dayStartToDateTime(String time) {
        return stringToDate(dayStart(time), COMMON_TIME_FORMAT);
    }

	public static Date dayEnd(Date time, String pattern) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(time);
		calendar.set(Calendar.HOUR_OF_DAY, 23);
		calendar.set(Calendar.MINUTE, 59);
		calendar.set(Calendar.SECOND, 59);
		return calendar.getTime();
	}

	public static String dayEnd(String time, String pattern) {
		return dateToString(dayEnd(stringToDate(time, pattern), pattern), pattern);
	}

	public static String dayEnd(String time) {
		return dateToString(dayEnd(stringToDate(time, COMMON_TIME_FORMAT), COMMON_TIME_FORMAT), COMMON_TIME_FORMAT);
	}

	public static Date dayEndToDateTime(String time) {
		return stringToDate(dayEnd(time), COMMON_TIME_FORMAT);
	}

	public static Date addDays(Date time, int days) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(time);
		cal.add(Calendar.DAY_OF_YEAR, days);
		return cal.getTime();
	}

	public static Date getBeforeDay(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_MONTH, -1);
		date = calendar.getTime();
		return date;
	}


	public static Date getCurrentDay(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_MONTH, 0);
		date = calendar.getTime();
		return date;
	}

	public static Date getNextDay(Date date) {
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_MONTH, 1);
		date = calendar.getTime();
		return date;
	}

	/**
	 * 增加分钟数
	 * @param time
	 * @param minutes
	 * @return
	 */
	public static Date addMinutes(Date time, int minutes) {
		Calendar cal = Calendar.getInstance();
		cal.setTime(time);
		cal.add(Calendar.MINUTE, minutes);
		return cal.getTime();
	}

	/**
	 * 判断time是否在from，to之内
	 *
	 * @param time 指定日期
	 * @param from 开始日期
	 * @param to   结束日期
	 * @return
	 */
	public static boolean belongCalendar(Date time, Date from, Date to) {
		Calendar date = Calendar.getInstance();
		date.setTime(time);

		Calendar after = Calendar.getInstance();
		after.setTime(from);

		Calendar before = Calendar.getInstance();
		before.setTime(to);

		return (date.after(after) || date.equals(after)) && (date.before(before) || date.equals(before));
	}

	/**
     * 相差分钟数
     * 
     * @param early
     * @param late
     * @return
     */
    public static long minutesBetween(Date early, Date late) {
        Calendar c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();
        c1.setTime(early);
        c2.setTime(late);
        long timeOne = c1.getTimeInMillis();
        long timeTwo = c2.getTimeInMillis();
        long minutes = (timeTwo - timeOne) / (1000 * 60); // 转化minute
        return minutes;
    }

    /**
     * 相差秒数
     * 
     * @param early
     * @param late
     * @return
     */
    public static long secondsBetween(Date early, Date late) {
        Calendar c1 = Calendar.getInstance();
        Calendar c2 = Calendar.getInstance();
        c1.setTime(early);
        c2.setTime(late);
        long timeOne = c1.getTimeInMillis();
        long timeTwo = c2.getTimeInMillis();
        long seconds = (timeTwo - timeOne) / 1000; // 转化second
        return seconds;
    }

    /**
     * 主函数
     */
	public static void main(String[] args) {

        // 打印测试
        Date time1 = stringToDate("2017-3-11");
        Date time2 = stringToDate("2017-3-12");
        Date time3 = stringToDate("2017-3-17");
        Date from = stringToDate("2017-3-12");
        Date to = stringToDate("2017-3-16");
        System.out.println(belongCalendar(time1, from, to));
        System.out.println(belongCalendar(time2, from, to));
        System.out.println(belongCalendar(time3, from, to));
        System.out.println(daysBetween(time3,time2));
        System.out.println(daysBetween(from,time3));
	}
}
